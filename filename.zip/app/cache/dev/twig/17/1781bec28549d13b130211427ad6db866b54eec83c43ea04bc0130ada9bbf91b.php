<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_e0406bffd20122cbf2e100aa9ed4dc3370d7bbb4367fb3106f38f2fea0603b41 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_557fb37ddd69da3315655c07777680fd42d6061db880fa3d6b9221a63da906d1 = $this->env->getExtension("native_profiler");
        $__internal_557fb37ddd69da3315655c07777680fd42d6061db880fa3d6b9221a63da906d1->enter($__internal_557fb37ddd69da3315655c07777680fd42d6061db880fa3d6b9221a63da906d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_557fb37ddd69da3315655c07777680fd42d6061db880fa3d6b9221a63da906d1->leave($__internal_557fb37ddd69da3315655c07777680fd42d6061db880fa3d6b9221a63da906d1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
