<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_20acf31aa62caced1c1cc2210f0ead882351fe0203feca4df11cb0ae11e2a0fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9abadbaba443ef6f63e164046cba1ef8fe23fd429d0069f1b942158369e3cc8e = $this->env->getExtension("native_profiler");
        $__internal_9abadbaba443ef6f63e164046cba1ef8fe23fd429d0069f1b942158369e3cc8e->enter($__internal_9abadbaba443ef6f63e164046cba1ef8fe23fd429d0069f1b942158369e3cc8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_9abadbaba443ef6f63e164046cba1ef8fe23fd429d0069f1b942158369e3cc8e->leave($__internal_9abadbaba443ef6f63e164046cba1ef8fe23fd429d0069f1b942158369e3cc8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
