<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_f8381e235c2d0cb70ca147802779ff0a0fe386d18f57a493e0e656f5a9c1e43e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6194ec53808ab7c1879c173855fef90e4edb920881e0667ff5572edce7281b06 = $this->env->getExtension("native_profiler");
        $__internal_6194ec53808ab7c1879c173855fef90e4edb920881e0667ff5572edce7281b06->enter($__internal_6194ec53808ab7c1879c173855fef90e4edb920881e0667ff5572edce7281b06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_6194ec53808ab7c1879c173855fef90e4edb920881e0667ff5572edce7281b06->leave($__internal_6194ec53808ab7c1879c173855fef90e4edb920881e0667ff5572edce7281b06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
