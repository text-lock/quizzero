<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_93125311965f977ad085e829713fb89cc98e4d71362c2a8e98cac328dfaefe74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5efae0bc89d073aae3e1a69b620e876b0e2fbf824bd411c82fd787298ae6c5d6 = $this->env->getExtension("native_profiler");
        $__internal_5efae0bc89d073aae3e1a69b620e876b0e2fbf824bd411c82fd787298ae6c5d6->enter($__internal_5efae0bc89d073aae3e1a69b620e876b0e2fbf824bd411c82fd787298ae6c5d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_5efae0bc89d073aae3e1a69b620e876b0e2fbf824bd411c82fd787298ae6c5d6->leave($__internal_5efae0bc89d073aae3e1a69b620e876b0e2fbf824bd411c82fd787298ae6c5d6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
