<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_b9eba220082db872644fa51a5ccd90619b3ca71ce400ec7cfede133f4155c436 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88f5e2c1e45cef967564d06d878bd35263f71a5083fab0473bd53c7cd505e6ed = $this->env->getExtension("native_profiler");
        $__internal_88f5e2c1e45cef967564d06d878bd35263f71a5083fab0473bd53c7cd505e6ed->enter($__internal_88f5e2c1e45cef967564d06d878bd35263f71a5083fab0473bd53c7cd505e6ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_88f5e2c1e45cef967564d06d878bd35263f71a5083fab0473bd53c7cd505e6ed->leave($__internal_88f5e2c1e45cef967564d06d878bd35263f71a5083fab0473bd53c7cd505e6ed_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
