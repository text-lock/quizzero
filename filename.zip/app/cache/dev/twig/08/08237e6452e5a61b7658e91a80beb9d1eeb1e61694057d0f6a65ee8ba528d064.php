<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_42f89f682468d1097774f5a08accfabde11da1e03e14b58146191a32885705fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a91e3bd8bdc56b820d33a5219832b9e025609ef174381384884e45a92f35f9ca = $this->env->getExtension("native_profiler");
        $__internal_a91e3bd8bdc56b820d33a5219832b9e025609ef174381384884e45a92f35f9ca->enter($__internal_a91e3bd8bdc56b820d33a5219832b9e025609ef174381384884e45a92f35f9ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_a91e3bd8bdc56b820d33a5219832b9e025609ef174381384884e45a92f35f9ca->leave($__internal_a91e3bd8bdc56b820d33a5219832b9e025609ef174381384884e45a92f35f9ca_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
