<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_3722a616c29f6087760b73444380886f983b7b5fdf86b6e99810f8ee677bed55 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ecbde47df58f11d057f92df106c1666ee51e81849befcfdb5ed7a97d40acfeb = $this->env->getExtension("native_profiler");
        $__internal_6ecbde47df58f11d057f92df106c1666ee51e81849befcfdb5ed7a97d40acfeb->enter($__internal_6ecbde47df58f11d057f92df106c1666ee51e81849befcfdb5ed7a97d40acfeb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_6ecbde47df58f11d057f92df106c1666ee51e81849befcfdb5ed7a97d40acfeb->leave($__internal_6ecbde47df58f11d057f92df106c1666ee51e81849befcfdb5ed7a97d40acfeb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
