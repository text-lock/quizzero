<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_2552634bb0ef7c8f3d006657cc06bfeaec59ca9a42c0f33add04ac65fa090b48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f42cf97086ddedc26ee2335b92e47e26e0a2724fe42896fb5946271a81fb36d0 = $this->env->getExtension("native_profiler");
        $__internal_f42cf97086ddedc26ee2335b92e47e26e0a2724fe42896fb5946271a81fb36d0->enter($__internal_f42cf97086ddedc26ee2335b92e47e26e0a2724fe42896fb5946271a81fb36d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_f42cf97086ddedc26ee2335b92e47e26e0a2724fe42896fb5946271a81fb36d0->leave($__internal_f42cf97086ddedc26ee2335b92e47e26e0a2724fe42896fb5946271a81fb36d0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
