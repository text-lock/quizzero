<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_d0644ccde4977f4687d4620d0e3882e22eeded27416ef145f1e51a15c105c67e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8378ebe468bf6252df09f3800d851230f45336619b32fcdc38130aecc4852d5e = $this->env->getExtension("native_profiler");
        $__internal_8378ebe468bf6252df09f3800d851230f45336619b32fcdc38130aecc4852d5e->enter($__internal_8378ebe468bf6252df09f3800d851230f45336619b32fcdc38130aecc4852d5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_8378ebe468bf6252df09f3800d851230f45336619b32fcdc38130aecc4852d5e->leave($__internal_8378ebe468bf6252df09f3800d851230f45336619b32fcdc38130aecc4852d5e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
