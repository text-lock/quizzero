<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_f14502edf9d9e8496b916c891f78b1d6b7533c0e551584dc04c0f934c93c1bf1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd9dc328295e6c6aeacd6c2ac8b05147deadd06fc0993750848c75edb7dd4b9f = $this->env->getExtension("native_profiler");
        $__internal_cd9dc328295e6c6aeacd6c2ac8b05147deadd06fc0993750848c75edb7dd4b9f->enter($__internal_cd9dc328295e6c6aeacd6c2ac8b05147deadd06fc0993750848c75edb7dd4b9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_cd9dc328295e6c6aeacd6c2ac8b05147deadd06fc0993750848c75edb7dd4b9f->leave($__internal_cd9dc328295e6c6aeacd6c2ac8b05147deadd06fc0993750848c75edb7dd4b9f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
