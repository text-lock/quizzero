<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_d6fcdcce6b37010bc5141d6047783f17e705c34257294842619af3525551efea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_013b269ac4379a4b5e2e26f623fe9195389682910381685268ef494264674a2d = $this->env->getExtension("native_profiler");
        $__internal_013b269ac4379a4b5e2e26f623fe9195389682910381685268ef494264674a2d->enter($__internal_013b269ac4379a4b5e2e26f623fe9195389682910381685268ef494264674a2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_013b269ac4379a4b5e2e26f623fe9195389682910381685268ef494264674a2d->leave($__internal_013b269ac4379a4b5e2e26f623fe9195389682910381685268ef494264674a2d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
