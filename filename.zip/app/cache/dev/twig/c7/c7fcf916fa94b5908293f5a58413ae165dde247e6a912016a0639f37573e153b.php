<?php

/* QuizzeroQuizBundle::user.layout.html.twig */
class __TwigTemplate_547802b7c823dc094da3185d7f51b415dedad3b699ddbd98b6f4063fcc314737 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30f0c3d30c583a12d83b7b146bb26c7320976264681d29528111b8e155a382ad = $this->env->getExtension("native_profiler");
        $__internal_30f0c3d30c583a12d83b7b146bb26c7320976264681d29528111b8e155a382ad->enter($__internal_30f0c3d30c583a12d83b7b146bb26c7320976264681d29528111b8e155a382ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "QuizzeroQuizBundle::user.layout.html.twig"));

        // line 1
        echo "<div class=\"col-md-3\"><a href=\"/admin/quiz\">Manage quiz</a></div>
<div class=\"col-md-3\"><a href=\"/\">Take a quiz</div>
<div class=\"col-md-3\"><a href=\"/profile/edit\">Edit user profile</div>
<div class=\"col-md-3\"><a href=\"/logout\">Logout</a></div>
";
        
        $__internal_30f0c3d30c583a12d83b7b146bb26c7320976264681d29528111b8e155a382ad->leave($__internal_30f0c3d30c583a12d83b7b146bb26c7320976264681d29528111b8e155a382ad_prof);

    }

    public function getTemplateName()
    {
        return "QuizzeroQuizBundle::user.layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div class="col-md-3"><a href="/admin/quiz">Manage quiz</a></div>*/
/* <div class="col-md-3"><a href="/">Take a quiz</div>*/
/* <div class="col-md-3"><a href="/profile/edit">Edit user profile</div>*/
/* <div class="col-md-3"><a href="/logout">Logout</a></div>*/
/* */
