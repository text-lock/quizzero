<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_ca25c6d449a0531e042df3d8b2cb2c4add9f4477bf8443ac30e52e816e0dc82c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e1f9f04bbd73f0e5ceba340cb64823cbaf796ee29a1fe351bab943b3f1d8cc43 = $this->env->getExtension("native_profiler");
        $__internal_e1f9f04bbd73f0e5ceba340cb64823cbaf796ee29a1fe351bab943b3f1d8cc43->enter($__internal_e1f9f04bbd73f0e5ceba340cb64823cbaf796ee29a1fe351bab943b3f1d8cc43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_e1f9f04bbd73f0e5ceba340cb64823cbaf796ee29a1fe351bab943b3f1d8cc43->leave($__internal_e1f9f04bbd73f0e5ceba340cb64823cbaf796ee29a1fe351bab943b3f1d8cc43_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
