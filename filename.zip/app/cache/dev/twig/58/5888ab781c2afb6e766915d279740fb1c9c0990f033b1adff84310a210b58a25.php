<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_c130269a2c3251ecb766b43a55e8f716848e016fc4aaf7f31a99a5a17291a19b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4519f6359256d3d1e2ca98dba999c9e126ca3e7ff0de79c24dcfdb252a15b08d = $this->env->getExtension("native_profiler");
        $__internal_4519f6359256d3d1e2ca98dba999c9e126ca3e7ff0de79c24dcfdb252a15b08d->enter($__internal_4519f6359256d3d1e2ca98dba999c9e126ca3e7ff0de79c24dcfdb252a15b08d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_4519f6359256d3d1e2ca98dba999c9e126ca3e7ff0de79c24dcfdb252a15b08d->leave($__internal_4519f6359256d3d1e2ca98dba999c9e126ca3e7ff0de79c24dcfdb252a15b08d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
