<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_e72794288709fb9c00ad9807da99ad921872f92490fbf1ea518734125e2f3f7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f671aa61e5576728bef6fa3383ba6694050decdb43927fee006dd6891aef8e8 = $this->env->getExtension("native_profiler");
        $__internal_1f671aa61e5576728bef6fa3383ba6694050decdb43927fee006dd6891aef8e8->enter($__internal_1f671aa61e5576728bef6fa3383ba6694050decdb43927fee006dd6891aef8e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_1f671aa61e5576728bef6fa3383ba6694050decdb43927fee006dd6891aef8e8->leave($__internal_1f671aa61e5576728bef6fa3383ba6694050decdb43927fee006dd6891aef8e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
