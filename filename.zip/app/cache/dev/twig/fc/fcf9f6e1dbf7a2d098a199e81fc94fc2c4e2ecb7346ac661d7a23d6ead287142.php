<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_18f1ffeae73cb3602b48657e73ae6a2b597f181566872656b0ad76bd4302fdaf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa89ee606a9c88991682e4a1fbdc8ca3dc09988f5e3fa0fc5a2b1b7c02e6c039 = $this->env->getExtension("native_profiler");
        $__internal_fa89ee606a9c88991682e4a1fbdc8ca3dc09988f5e3fa0fc5a2b1b7c02e6c039->enter($__internal_fa89ee606a9c88991682e4a1fbdc8ca3dc09988f5e3fa0fc5a2b1b7c02e6c039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_fa89ee606a9c88991682e4a1fbdc8ca3dc09988f5e3fa0fc5a2b1b7c02e6c039->leave($__internal_fa89ee606a9c88991682e4a1fbdc8ca3dc09988f5e3fa0fc5a2b1b7c02e6c039_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
