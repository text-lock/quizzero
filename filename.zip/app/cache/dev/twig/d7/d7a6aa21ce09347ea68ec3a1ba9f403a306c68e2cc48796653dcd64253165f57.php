<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_2d58bbb77c4df98be7673f44f2322b4c728cac05f5c1ff5b2b51795ccfe855ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ce8b28dac09ff0210f40fc171e9891530f706275b9a0f7bcfd5fb1b7bd84338 = $this->env->getExtension("native_profiler");
        $__internal_1ce8b28dac09ff0210f40fc171e9891530f706275b9a0f7bcfd5fb1b7bd84338->enter($__internal_1ce8b28dac09ff0210f40fc171e9891530f706275b9a0f7bcfd5fb1b7bd84338_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_1ce8b28dac09ff0210f40fc171e9891530f706275b9a0f7bcfd5fb1b7bd84338->leave($__internal_1ce8b28dac09ff0210f40fc171e9891530f706275b9a0f7bcfd5fb1b7bd84338_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
