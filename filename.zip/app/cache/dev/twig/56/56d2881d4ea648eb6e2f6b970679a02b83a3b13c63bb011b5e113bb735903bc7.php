<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_3ab6038c3ebabc0ed95bf2382186e1104e4221fe66088c06def76f1ccd17567b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5731fd4a9940e082655f24ff7fbae817a35e53c0d9259a06f645cddb9281629f = $this->env->getExtension("native_profiler");
        $__internal_5731fd4a9940e082655f24ff7fbae817a35e53c0d9259a06f645cddb9281629f->enter($__internal_5731fd4a9940e082655f24ff7fbae817a35e53c0d9259a06f645cddb9281629f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_5731fd4a9940e082655f24ff7fbae817a35e53c0d9259a06f645cddb9281629f->leave($__internal_5731fd4a9940e082655f24ff7fbae817a35e53c0d9259a06f645cddb9281629f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
