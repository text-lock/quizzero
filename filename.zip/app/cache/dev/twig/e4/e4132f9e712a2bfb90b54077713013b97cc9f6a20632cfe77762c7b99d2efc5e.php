<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_c6484b1019c073c993afcc79c4ace678fe536583c50142477b75b02360e0f837 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d876cf59e3ac9b00b78918c36cf79bb485f265fa41ae7c918632e4b1cbc6d68 = $this->env->getExtension("native_profiler");
        $__internal_3d876cf59e3ac9b00b78918c36cf79bb485f265fa41ae7c918632e4b1cbc6d68->enter($__internal_3d876cf59e3ac9b00b78918c36cf79bb485f265fa41ae7c918632e4b1cbc6d68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_3d876cf59e3ac9b00b78918c36cf79bb485f265fa41ae7c918632e4b1cbc6d68->leave($__internal_3d876cf59e3ac9b00b78918c36cf79bb485f265fa41ae7c918632e4b1cbc6d68_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
