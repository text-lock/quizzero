<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_a7ad57f65566b1a0f835eadc72eae7eafd647ad8dc447c54c193f0af7e3048df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bcad6ddd0fc6b7d178730b4b9323c0bb2e632b103964686199c7d9326502d882 = $this->env->getExtension("native_profiler");
        $__internal_bcad6ddd0fc6b7d178730b4b9323c0bb2e632b103964686199c7d9326502d882->enter($__internal_bcad6ddd0fc6b7d178730b4b9323c0bb2e632b103964686199c7d9326502d882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_bcad6ddd0fc6b7d178730b4b9323c0bb2e632b103964686199c7d9326502d882->leave($__internal_bcad6ddd0fc6b7d178730b4b9323c0bb2e632b103964686199c7d9326502d882_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
