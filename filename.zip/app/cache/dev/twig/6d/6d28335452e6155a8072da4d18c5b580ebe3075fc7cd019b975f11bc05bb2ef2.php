<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_c45862bf60457247c59f0e2b200a13f7f67ef834345c5d15f660f139d1c6517a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3643e7d6d976bea431b77db29be5e778d350f595392e2fabcf029e0a24a593ce = $this->env->getExtension("native_profiler");
        $__internal_3643e7d6d976bea431b77db29be5e778d350f595392e2fabcf029e0a24a593ce->enter($__internal_3643e7d6d976bea431b77db29be5e778d350f595392e2fabcf029e0a24a593ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_3643e7d6d976bea431b77db29be5e778d350f595392e2fabcf029e0a24a593ce->leave($__internal_3643e7d6d976bea431b77db29be5e778d350f595392e2fabcf029e0a24a593ce_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
