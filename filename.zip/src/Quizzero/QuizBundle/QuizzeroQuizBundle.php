<?php

namespace Quizzero\QuizBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class QuizzeroQuizBundle extends Bundle
{
}
