quizzero
========

A Symfony project created on July 4, 2016, 8:55 pm.


TODO

- Fix image uppload error ()
- Redirect to a Question list after create new quiz.
- Hide Get your result btn on empty quizzes.
- Allow blank fields, fix JS and annotations.
- Show image previue in edit form
- Fix JS errors on create and attach new questions to quiz.

- redirect to right route when question added
- Chex manage quiz for non admin users